from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from datetime import timedelta

app = Flask(__name__)

app.config['SECRET_KEY'] = '85892d6b73d8438bac182e2ea42e58a4'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///assignment3.db'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes = 10)
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

class User(db.Model):
    __tablename__ = 'User'
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(30), unique=True, nullable=False)
    password = db.Column(db.String(130), nullable=False)
    user_type = db.Column(db.String(20), nullable=False)
    grades = db.relationship('Grades', backref='author', lazy=True)
    feedback = db.relationship('Feedback', backref='author', lazy=True)

class Grades(db.Model):
    __tablename__ = 'Grades'
    mark_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('User.user_id'), nullable=False)
    assessment_name = db.Column(db.String(20), nullable=False)
    mark = db.Column(db.Integer, nullable=False)

class Remark_Requests(db.Model):
    __tablename__ = 'Remark_Requests'
    remark_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('User.user_id'), nullable=False)
    assessment_name = db.Column(db.String(20), nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False)

class Feedback(db.Model):
    __tablename__ = 'Feedback'
    feedback_id = db.Column(db.Integer, primary_key=True)
    instructor_id = db.Column(db.Integer, db.ForeignKey('User.user_id'), nullable=False)
    general_feedback = db.Column(db.Text, nullable=False)
    q1 = db.Column(db.Text, nullable=False)
    q2 = db.Column(db.Text, nullable=False)
    q3 = db.Column(db.Text, nullable=False)
    q4 = db.Column(db.Text, nullable=False)

@app.route("/")
@app.route("/home")
def home():
    return render_template("index.html")

@app.route("/modules")
def modules():
    pagename = "Modules"
    return render_template("modules.html", pagename=pagename)

@app.route("/assignments")
def assignments():
    pagename = "Assignments"
    return render_template("assignments.html", pagename=pagename)

@app.route("/tests")
def tests():
    pagename = "Tests"
    return render_template("tests.html", pagename=pagename)

@app.route("/resources")
def resources():
    pagename = "Resources"
    return render_template("resources.html", pagename=pagename)

@app.route("/calendar")
def calendar():
    pagename = "Calendar"
    return render_template("calendar.html", pagename=pagename)

@app.route("/feedback", methods=['GET', 'POST'])
def feedback():
    pagename = "Feedback"
    if request.method == 'POST':
        instructor_id = request.form['Instructor']
        general_feedback = request.form['General_feedback']
        q1_feedback = request.form['Q1']
        q2_feedback = request.form['Q2']
        q3_feedback = request.form['Q3']
        q4_feedback = request.form['Q4']
        feedback_details = (instructor_id, 
                            general_feedback, 
                            q1_feedback, 
                            q2_feedback, 
                            q3_feedback, 
                            q4_feedback)
        add_feedback(feedback_details)
        flash('Feedback Submitted Successfully!')
        return redirect(url_for('feedback'))
        
    instructors = query_instructors()
    return render_template("feedback.html", pagename=pagename, instructors=instructors)

@app.route("/remark_request", methods=["GET"])
def remark_request():
    pagename = "Remark Request"
    if request.method == 'GET':
        if session['user_type'] == 'Instructor':
            remark_requests = query_remarks()
        else:
             current_user = User.query.filter_by(username=session['name']).first()
             remark_requests = query_student_remarks(current_user)

        return render_template("remark_requests.html", pagename=pagename, remark_requests=remark_requests)

@app.route("/submit_request", methods=['GET', 'POST'])
def submit_remark():
    pagename = "Submit Remark Request"
    if request.method=='GET':
        assessments = query_assessments()
        return render_template("submit_request.html", pagename=pagename, assessments=assessments)
    else:
        student = User.query.filter_by(username=session['name']).first()
        student_id = student.user_id
        assessment_name = request.form["Assessment"]
        reason = request.form["Reason"]
        status="Pending"
        remark_details = (student_id,
                          assessment_name,
                          reason,
                          status)
        add_remark(remark_details)
        flash("Remark Submitted Successfully")
        return redirect(url_for('remark_request'))

@app.route("/update_status", methods=['POST'])
def update_status():
    if request.method=='POST':    
        remark_id = request.form['Remark_id']
        new_status = request.form["New_status"]

        remark = Remark_Requests.query.get(remark_id)

        remark.status = new_status
        db.session.commit()

        return redirect(url_for("remark_request"))

@app.route("/add_marks", methods=["GET", "POST"])
def mark_addition():
    pagename = "Grades"
    if request.method=='GET':
        students = query_students()
        return render_template("add_marks.html", pagename=pagename, students=students)
    else:
        student_id = request.form['Student']
        assessment_name = request.form['Assessment']
        mark = request.form['Grade']
        grade_details = (student_id, 
                         assessment_name,
                         mark)
        add_grade(grade_details)
        flash("Grade Added Successfully")
        return redirect(url_for('mark_addition'))

@app.route("/course-team")
def course_team():
    pagename = "Course Team"
    return render_template("course-team.html", pagename=pagename)

@app.route("/grades", methods=['GET'])
def grades():
    pagename = "Grades"
    if request.method=='GET':
        if session['user_type'] == "Instructor":
            marks = query_marks()
        else:
            current_user = User.query.filter_by(username=session['name']).first()
            marks = query_student_marks(current_user)

        return render_template("grades.html", pagename=pagename, marks=marks)
    
@app.route("/view_feedback", methods=['GET'])
def view_feedback():
    pagename = "Feedback"
    if request.method=='GET':
        all_feedback = db.session.query(Feedback, User.username).join(User, Feedback.instructor_id == User.user_id).all()
        return render_template("view_feedback.html", pagename=pagename, all_feedback=all_feedback)

@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method=='GET':
        return render_template("register.html")
    else:
        user_type = request.form['User_type']
        username = request.form['Username']
        email = request.form['Email']

        existing_user = User.query.filter((User.username == username) or (User.email == email)).first()

        if existing_user:
            if existing_user.username == username or existing_user.email == email:
                flash("The username/email has already been taken. Please try again")
            return redirect(url_for('register'))
        
        hashed_password = bcrypt.generate_password_hash(request.form['Password']).decode('utf-8')
        registration_details = (user_type, username, email, hashed_password)
        add_user(registration_details)
        flash('Registration Successful! You may now login!')
        return redirect(url_for('login'))

@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        if 'name' in session:
            flash('Already logged in!')
            return redirect(url_for('message'))
        else:
            return render_template("login.html")
    else:
        username=request.form['Username']
        password=request.form['Password']
        user = User.query.filter_by(username=username).first()

        if not user or not bcrypt.check_password_hash(user.password, password):
            flash('Please check your login details and try again', 'error')
            return render_template('login.html')
        else:
            session["name"] = user.username
            session["user_type"] = user.user_type
            session.permanent=True
            return redirect(url_for('message'))
        
@app.route("/message")
def message():
    pagename = "Personalized Message"
    return render_template("message.html", pagename=pagename)

@app.route('/logout')
def logout():
    session.pop('name', default = None)
    flash("You have logged out successfully.")
    return render_template("logout.html")

def query_instructors():
    query_instructor = User.query.filter_by(user_type='Instructor').all()
    return query_instructor

def query_students():
    query_student = User.query.filter_by(user_type='Student').all()
    return query_student

def query_marks():
    query_mark = db.session.query(Grades, User.username).join(User, Grades.student_id==User.user_id).all()
    #Here, we are joining Grades with one column from the User relation, the username attribute, on the condition
    #that student_id=user_id. This is to show the username in the table in grades.html along with attributes from the Grades relation
    return query_mark

def query_student_marks(user):
    query_student_mark = db.session.query(Grades, User.username).join(User, Grades.student_id==User.user_id).filter(User.user_id == user.user_id).all()
    return query_student_mark

def query_remarks():
    query_request = db.session.query(Remark_Requests, User.username).join(User, Remark_Requests.student_id == User.user_id).all()
    return query_request

def query_student_remarks(user):
    query_student_remark = db.session.query(Remark_Requests, User.username).join(User, Remark_Requests.student_id==User.user_id).filter(User.user_id == user.user_id).all()
    return query_student_remark

def query_assessments():
    query_assessment = db.session.query(Grades.assessment_name).distinct().all()
    return query_assessment

def add_user(registration_details):
    user = User(user_type=registration_details[0], 
                username=registration_details[1], 
                email = registration_details[2], 
                password = registration_details[3])
    db.session.add(user)
    db.session.commit()

def add_feedback(feedback_details):
    feedback = Feedback(instructor_id=feedback_details[0], 
                        general_feedback=feedback_details[1], 
                        q1=feedback_details[2], 
                        q2=feedback_details[3],
                        q3=feedback_details[4], 
                        q4=feedback_details[5])
    db.session.add(feedback)
    db.session.commit()

def add_grade(grade_details):
    grade = Grades(student_id=grade_details[0], 
                  assessment_name=grade_details[1], 
                  mark=grade_details[2])
    db.session.add(grade)
    db.session.commit()

def add_remark(remark_details):
    remark = Remark_Requests(student_id=remark_details[0], 
                             assessment_name=remark_details[1],
                             reason=remark_details[2],
                             status=remark_details[3])
    db.session.add(remark)
    db.session.commit()

if __name__ == '__main__':
    app.run(debug=True)


